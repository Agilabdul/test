<!DOCTYPE html>
<html lang="en">
<head>
  <title>Register Akun</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="aset/bootstrap/css/bootstrap3.min.css">
</head>
<body>
<div class="container">
  <br>
  <div class="row">
    <div class="col-md-3"></div>
    <div class="col-md-6">
      <div class="panel panel-default">
          <div class="panel-heading" align="center">
            <h3>Daftar Akun</h3>
          </div>
          <div class="panel-body">
            <?php
              include "koneksi.php";
              if (isset($_POST['daftar'])) {
                  $nik        = $_POST['nik'];
                  $nama       = $_POST['nama'];
                  $username   = $_POST['username'];
                  $password   = md5($_POST['password']);
                  $telp       = $_POST['telp'];
                  $email      = $_POST['email'];
                  $aktivasi   = 0;
                  $token      = hash('sha256', md5(date('Y-m-d'))) ;
                  $created_at = date("d M Y, h:i:s A");
                  $created_by = '-';
                  $sql_cek    = mysqli_query($koneksi,"SELECT * FROM masyarakat WHERE email='$email'");
                  $cek_email  = mysqli_num_rows($sql_cek);
                  if ($cek_email>0) {
                    echo '<div class="alert alert-danger text-center">
                            Email yang anda masukan, sudah pernah mendaftar!
                          </div>';
                  }else{
                    $insert = mysqli_query($koneksi,"INSERT INTO masyarakat(nik,nama,username,password,telp,email,aktivasi,token,created_at,created_by) 
                    VALUES('$nik','$nama','$username','$password','$telp','$email','$aktivasi','$token','$created_at','$created_by')");
                    include("mail.php");
                  }                  
              }
            ?>
            <?php 
                if(isset($_GET['aktivasi'])){
                    if($_GET['aktivasi'] == "berhasil"){
                        echo "<div class='alert alert-success text-center' role='alert'>
                                Berhasil mendaftar! silahkan cek email untuk aktivasi akun anda. 
                                <a href='login.php'>Login</a>
                              </div>";
                    }
                }
            ?> 
            <form class="form-horizontal" method="POST">
              <div class="form-group">
                <label class="control-label col-sm-3" for="nik">NIK :</label>
                <div class="col-sm-9">
                  <input type="number" class="form-control" id="nik" name="nik" required>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-sm-3" for="nama">Nama :</label>
                <div class="col-sm-9">
                  <input type="text" class="form-control" id="nama" name="nama" required>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-sm-3" for="username">Username :</label>
                <div class="col-sm-9">
                  <input type="text" class="form-control" id="username" name="username" required>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-sm-3" for="password">Password :</label>
                <div class="col-sm-9">          
                  <input type="password" class="form-control" id="password" name="password" required>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-sm-3" for="telp">No. Telp :</label>
                <div class="col-sm-9">
                  <input type="number" class="form-control" id="telp" name="telp" required>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-sm-3" for="email">Email :</label>
                <div class="col-sm-9">          
                  <input type="email" class="form-control" id="email" name="email" required>
                </div>
              </div>
              <div class="form-group">        
                <div class="col-sm-offset-3 col-sm-9">
                  <button type="submit" name="daftar" class="btn btn-primary btn-block">Daftar</button>
                </div>
              </div>
            </form>
              Sudah punya akun? <a href="login.php">Login</a>
          </div>
        </div>      
    </div>
  </div>
</div>
<script src="aset/bootstrap/js/jquery.min.js"></script>
<script src="aset/bootstrap/js/bootstrap3.min.js"></script>
</body>
</html>
