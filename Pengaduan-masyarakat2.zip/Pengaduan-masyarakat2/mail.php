<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require "libraries/autoload.php";
$mail = new PHPMailer(true);
$mail->SMTPDebug = 0;
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
//ganti dengan email dan password yang akan di gunakan sebagai email pengirim
$mail->Username = 'agilabdul900@gmail.com';
$mail->Password = 'AgilMustofa18';
$mail->SMTPSecure = 'tls';
$mail->Port = 587;
//ganti dengan email yg akan di gunakan sebagai email pengirim
$mail->setFrom('agilabdul900@gmail.com', 'Administrator');
$mail->addAddress($_POST['email']);
$mail->isHTML(true);
$mail->Subject = "Aktivasi Akun Sistem Pengaduan Masyarakat";
$mail->Body = " Silahkan klik link dibawah ini untuk aktivasi akun anda : <br>
                <a href='http://localhost/pengaduan-masyarakat/activation.php?token=".$token."'>
                    http://localhost/pengaduan-masyarakat/activation.php?token=".$token."
                </a>";
$mail->send();
header("location:register.php?aktivasi=berhasil");