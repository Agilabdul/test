<?php
  include '../koneksi.php';

  $tgl_pengaduan	= date('d M Y, H:i:s A');
  $nik			      = $_POST['nik'];
  $judul	        = $_POST['judul'];
  $isi_laporan	  = $_POST['isi_laporan'];
  $foto			      = $_FILES['foto']['name'];
  $status			    = 'proses';

  if($foto != null) {
    $ekstensi_diperbolehkan = array('svg','png','jpg');
    $x = explode('.', $foto);
    $ekstensi = strtolower(end($x));
    $file_tmp = $_FILES['foto']['tmp_name'];   
    $angka_acak     = rand(1,999);
    $foto_baru = $angka_acak.'-'.$foto;
    
    if(in_array($ekstensi, $ekstensi_diperbolehkan) === true)  {     
      move_uploaded_file($file_tmp, '../aset/upload_bukti/'.$foto_baru);
      $query = "INSERT INTO pengaduan (tgl_pengaduan, nik, judul, isi_laporan, foto, status) 
      VALUES ('$tgl_pengaduan', '$nik', '$judul', '$isi_laporan', '$foto_baru', '$status')";
      $result = mysqli_query($koneksi, $query);
        if(!$result){
            die ("Query gagal dijalankan: ".mysqli_errno($koneksi)." - ".mysqli_error($koneksi));
        } else {
          echo "<script>
                  alert('Pengaduan anda berhasil sampaikan, mohon untuk bersabar!');
                  window.location='tanggapan.php';
                </script>";
        }
    }else {     
        echo "<script>
                alert('Ekstensi arsip yang boleh hanya svg. png. jpg.');
                window.location='tanggapan.php';
              </script>";
    }
  } else {
      $query = "INSERT INTO pengaduan (tgl_pengaduan, nik, judul, isi_laporan, foto, status) 
      VALUES ('$tgl_pengaduan', '$nik', '$judul', '$isi_laporan',NULL, '$status')";
    $result = mysqli_query($koneksi, $query);
    if(!$result){
      die ("Query gagal dijalankan: ".mysqli_errno($koneksi).
        " - ".mysqli_error($koneksi));
    } else {
    echo "<script>alert('Pengaduan anda berhasil sampaikan, mohon untuk bersabar!');window.location='pengaduan.php';</script>";
    }
  }
?>