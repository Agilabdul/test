<?php 
    include('../koneksi.php');
    session_start();
    if($_SESSION['status']!="login"){
        header("location:../login.php?pesan=belum_login");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../aset/bootstrap/css/bootstrap.min.css">
    <title>Laporkan pengaduan anda</title>
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
            <div class="container">
                <a class="navbar-brand" href="index.php">Pengaduan Masyarakat</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item p-2">
                            <a class="nav-link" href="tanggapan.php">Lihat Tanggapan</a>
                        </li>
                        <li class="nav-item p-2">
                            <a class="nav-link active" href="pengaduan.php">Laporkan</a>
                        </li>
                        <li class="nav-item dropdown p-2">
                          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Hallo, <?= $_SESSION['username']; ?>
                          </a>
                          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="saya.php?nik=<?=$_SESSION['nik']?>">Pengaturan</a>
                            <a class="dropdown-item" href="../logout.php" onclick="return confirm('Anda yakin akan logout?')">Logout</a>
                          </div>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    
    <main role="main" style="margin-top: 100px;">
        <div class="container mt-3">
            <div class="row justify-content-md-center">
                <div class="col-8">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="text-center">FORM PENGADUAN</h4>
                            <form method="post" action="proses_pengaduan.php" enctype="multipart/form-data">
                                <div class="form-group">
                                    <input type="hidden" name="nik" class="form-control form-control-sm" id="nik" value="<?= $_SESSION['nik']; ?>">
                                </div>
                                <div class="form-group">
                                    <input type="text" name="judul" id="judul" placeholder="Judul Laporan" class="form-control form-control-sm" autocomplete="off" required>
                                </div>
                                <div class="form-group">
                                    <textarea class="form-control" name="isi_laporan" id="isi_laporan" placeholder="Isi laporan pengaduan/keluhan" rows="3" autocomplete="off" required></textarea>
                                </div>
                                <div class="form-group">
                                    <div class="custom-file mb-3">
                                        <input type="file" class="custom-file-input" id="foto" name="foto">
                                        <label class="custom-file-label" for="foto">Upload Bukti ...</label>
                                    </div>
                                </div>
                                <input type="submit" name="submit" value="Laporkan !" class="btn btn-danger btn-sm" style="float:right;">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <script src="../aset/bootstrap/js/jquery-3.5.1.slim.min.js"></script>
    <script src="../aset/bootstrap/js/popper.min.js"></script>
    <script src="../aset/bootstrap/js/bootstrap.min.js"></script>
    <script>
        $(".custom-file-input").on("change", function() {
            var fileName = $(this).val().split("\\").pop();
            $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
        });
    </script>
</body>
</html>