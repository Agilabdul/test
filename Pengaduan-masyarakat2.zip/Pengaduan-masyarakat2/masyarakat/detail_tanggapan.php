<?php 
    include('../koneksi.php');
    session_start();
    if($_SESSION['status']!="login"){
        header("location:../login.php?pesan=belum_login");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../aset/bootstrap/css/bootstrap.min.css">
    <title>Pengaduan Anda</title>
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
            <div class="container">
                <a class="navbar-brand" href="index.php">Pengaduan Masyarakat</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item p-2">
                            <a class="nav-link active" href="tanggapan.php">Lihat Tanggapan</a>
                        </li>
                        <li class="nav-item p-2">
                            <a class="nav-link" href="pengaduan.php">Laporkan</a>
                        </li>
                        <li class="nav-item dropdown p-2">
                          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Hallo, <?= $_SESSION['username']; ?>
                          </a>
                          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="saya.php?nik=<?=$_SESSION['nik']?>">Pengaturan</a>
                            <a class="dropdown-item" href="../logout.php" onclick="return confirm('Anda yakin akan logout?')">Logout</a>
                          </div>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    
    <main role="main" style="margin-top: 100px;">
        <div class="container mt-3">
            <div class="row">
                <?php 
                    $no = 1;
                    $nik = $_GET['nik'];
                    $id_pengaduan = $_GET['id_pengaduan'];
                    $data = mysqli_query($koneksi,"SELECT * FROM pengaduan WHERE nik='$nik' AND id_pengaduan='$id_pengaduan'");
                    while($d = mysqli_fetch_array($data)){?>
                    
                    <div class="col-8 mt-3">
                        <div class="card">
                            <div class="card-header">
                                <h4>Detail pengaduan anda</h4>
                            </div>
                            <div class="card-body">
                                <div class="media">

                                    <img src="../aset/img/avatar1.png" class="mr-3" alt="profile" width="50px">
                                    <div class="media-body">
                                        <b>Anda</b> <br>
                                        <small><em><?= $d['tgl_pengaduan'];?></em></small> <br>
                                        <p class="text-justify"><?= $d['isi_laporan'];?>?</p>
                                    
                                        <?php
                                            $id_pengaduan = $_GET['id_pengaduan'];
                                            $data = mysqli_query($koneksi,"SELECT * FROM tanggapan WHERE id_pengaduan='$id_pengaduan'");
                                            while($data_tanggapan = mysqli_fetch_array($data)){?>
                                            
                                            <hr>
                                            <div class="media mt-3">
                                                <a class="mr-3" href="#">
                                                    <img src="../aset/img/profile.png" class="mr-3" alt="profile" width="50px">
                                                </a>
                                                <div class="media-body">
                                                    <?php
                                                    $id_petugas = $data_tanggapan['id_petugas'];;
                                                    $data = mysqli_query($koneksi,"SELECT * FROM petugas WHERE id_petugas='$id_petugas'");
                                                    while($data_petugas = mysqli_fetch_array($data)){?>

                                                    <b><?= $data_petugas['nama_petugas'];?></b> <br>
                                                    
                                                    <?php
                                                    }?>
                                                    <small><em><?= $data_tanggapan['tgl_tanggapan'];?></em></small> <br>
                                                    <p class="text-justify"><?= $data_tanggapan['tanggapan'];?></p>
                                                </div>
                                            </div>
                                            <?php
                                            }
                                        ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                        <?php
                    }
                ?>
            </div>
        </div>
    </main>
    <script src="../aset/bootstrap/js/jquery-3.5.1.slim.min.js"></script>
    <script src="../aset/bootstrap/js/popper.min.js"></script>
    <script src="../aset/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>