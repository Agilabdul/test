<?php 
    include('../koneksi.php');
    session_start();
    if($_SESSION['status']!="login"){
        header("location:../login.php?pesan=belum_login");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../aset/bootstrap/css/bootstrap.min.css">
    <title>Pengaduan Anda</title>
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
            <div class="container">
                <a class="navbar-brand" href="index.php">Pengaduan Masyarakat</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item p-2">
                            <a class="nav-link active" href="tanggapan.php">Lihat Tanggapan</a>
                        </li>
                        <li class="nav-item p-2">
                            <a class="nav-link" href="pengaduan.php">Laporkan</a>
                        </li>
                        <li class="nav-item dropdown p-2">
                          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Hallo, <?= $_SESSION['username']; ?>
                          </a>
                          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="saya.php?nik=<?=$_SESSION['nik']?>">Pengaturan</a>
                            <a class="dropdown-item" href="../logout.php" onclick="return confirm('Anda yakin akan logout?')">Logout</a>
                          </div>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    
    <main role="main" style="margin-top: 100px;">
        <div class="container mt-3">
            <h4>Rekap data pengaduan anda</h4>
            <div class="row">
                <div class="col mt-3">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">NO</th>
                                <th scope="col">Judul</th>
                                <th scope="col">Tanggal Lapor</th>
                                <th scope="col">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php 
                            $no = 1;
                            $nik = $_SESSION['nik'];
                            $data = mysqli_query($koneksi,"SELECT * FROM pengaduan WHERE nik='$nik'");
                            while($data_pengaduan = mysqli_fetch_array($data)){?>
                            <tr>
                                <th><?= $no++?></th>
                                <td><?= $data_pengaduan['judul'];?></td>
                                <td><?= substr($data_pengaduan['tgl_pengaduan'],0,11);?></td>
                                <td>
                                    <?php 
                                        if ($data_pengaduan['status'] == "selesai") {
                                            echo "<a href='detail_tanggapan.php?nik=$_SESSION[nik]&id_pengaduan=$data_pengaduan[id_pengaduan]' class='badge badge-success'>Selesai</a>";
                                        }else {
                                            echo "<a href='detail_tanggapan.php?nik=$_SESSION[nik]&id_pengaduan=$data_pengaduan[id_pengaduan]' class='badge badge-warning'>Proses</a>";
                                        }
                                    ?>
                                </td>
                            </tr>   
                        <?php
                            }
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
    <script src="../aset/bootstrap/js/jquery-3.5.1.slim.min.js"></script>
    <script src="../aset/bootstrap/js/popper.min.js"></script>
    <script src="../aset/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>