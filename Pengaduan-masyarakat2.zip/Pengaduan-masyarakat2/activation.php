
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Aktivasi Akun</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="aset/bootstrap/css/bootstrap.min.css">
</head>
<body>
  <div class="container mt-5">
    <?php
      include "koneksi.php";
      $token=$_GET['token'];
      $sql_cek=mysqli_query($koneksi,"SELECT * FROM masyarakat WHERE token='".$token."' and aktivasi='0'");
      $jml_data=mysqli_num_rows($sql_cek);
      if ($jml_data>0) {
        mysqli_query($koneksi,"UPDATE masyarakat SET aktivasi='1' WHERE token='".$token."' and aktivasi='0'");
        echo '<div class="row">
                <div class="col-4"></div>
                  <div class="col-md-4">
                      <div class="card">
                          <h5 class="card-header text-center">Aktivasi akun berhasil</h5>
                          <div class="card-body">
                          <p class="card-text text-center">Terima Kasih telah melakukan aktivasi akun sistem informasi pengaduan masyarakat.</p>
                          <p class="card-text text-center" style="font-size:14px;">Klik tombol berikut untuk login akun Anda :</p>
                          <center><a href="login.php" class="btn btn-primary btn-sm">Login</a></center>
                          </div>
                      </div>
                  </div>
              </div>';
      }else{
        echo '<div class="alert alert-warning">Invalid Token!</div>';
        }
    ?>
  </div>
  <script src="aset/bootstrap/js/jquery-3.5.1.slim.min.js"></script>
  <script src="aset/bootstrap/js/popper.min.js"></script>
  <script src="aset/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
