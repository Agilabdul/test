<!DOCTYPE html>
<html lang="en">
<head>
  <title>Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="aset/bootstrap/css/bootstrap3.min.css">
</head>
<body>
<div class="container">
  <br>
  <div class="row">
    <div class="col-md-4"></div>
    <div class="col-md-4">
      <div class="panel panel-default">
          <div class="panel-heading" align="center">
            <h3>LOGIN!</h3>
          </div>
          <div class="panel-body">   
            <?php 
                if(isset($_GET['pesan'])){
                    if($_GET['pesan'] == "gagal"){
                        echo "<div class='alert alert-danger text-center' role='alert'>username dan password tidak sesuai!</div>";
                    }else if($_GET['pesan'] == "logout"){
                        echo "<div class='alert alert-success text-center' role='alert'>Anda berhasil Logout!</div>";
                    }else if($_GET['pesan'] == "belum_login"){
                        echo "<div class='alert alert-warning text-center' role='alert'>Harus login terlebih dulu!</div>";
                    }
                }
            ?> 
            <form class="form-horizontal" method="POST" action="validasi.php">
              <div class="form-group">
                <label class="control-label col-sm-3" for="username">Username:</label>
                <div class="col-sm-9">
                  <input type="text" class="form-control" id="username" name="username" required>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-sm-3" for="password">Password:</label>
                <div class="col-sm-9">          
                  <input type="password" class="form-control" id="password" name="password" required>
                </div>
              </div>
              <div class="form-group">        
                <div class="col-sm-offset-3 col-sm-9">
                  <button type="submit" name="login" class="btn btn-primary btn-block">Login</button>
                </div>
              </div>
            </form>
              Belum punya akun? <a href="register.php">Register</a>
          </div>
        </div>      
    </div>
  </div>
</div>
<script src="aset/bootstrap/js/jquery.min.js"></script>
<script src="aset/bootstrap/js/bootstrap3.min.js"></script>
</body>
</html>
