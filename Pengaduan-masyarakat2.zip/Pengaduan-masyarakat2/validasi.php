<?php 
    session_start();
    include 'koneksi.php';
    $username = $_POST['username'];
    $password = md5($_POST['password']);
    $login = mysqli_query($koneksi,"SELECT * FROM masyarakat WHERE username='$username' AND password='$password' AND aktivasi='1'");
    $cek = mysqli_num_rows($login);
    if($cek > 0){
        $data = mysqli_fetch_assoc($login);
            $_SESSION['nik'] = $data["nik"];
            $_SESSION['nama'] = $data["nama"];
            $_SESSION['username'] = $data["username"];
            $_SESSION['password'] = $data["password"];
            $_SESSION['telp'] = $data["telp"];
            $_SESSION['email'] = $data["email"];
            $_SESSION['created_at'] = $data["created_at"];
            $_SESSION['created_by'] = $data["created_by"];
            $_SESSION['status'] = "login";
            header("location:masyarakat/pengaduan.php");
    }else{
        header("location:login.php?pesan=gagal");
    }
?>