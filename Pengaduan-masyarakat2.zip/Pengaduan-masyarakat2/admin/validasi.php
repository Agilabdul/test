<?php 
    session_start();
    include '../koneksi.php';
    $username = $_POST['username'];
    $password = md5($_POST['password']);
    $login = mysqli_query($koneksi,"SELECT * FROM petugas WHERE username='$username' and password='$password'");
    $cek = mysqli_num_rows($login);
    if($cek > 0){
        $data = mysqli_fetch_assoc($login);
        if($data['level']=="Administrator"){
            $_SESSION['id_petugas'] = $data["id_petugas"];
            $_SESSION['nama_petugas'] = $data["nama_petugas"];
            $_SESSION['username'] = $data["username"];
            $_SESSION['password'] = $data["password"];
            $_SESSION['telp'] = $data["telp"];
            $_SESSION['level'] = "administrator";
            $_SESSION['status'] = "login";
            header("location:administrator/index.php");

        }else if($data['level']=="Petugas"){
            $_SESSION['id_petugas'] = $data["id_petugas"];
            $_SESSION['nama_petugas'] = $data["nama_petugas"];
            $_SESSION['username'] = $data["username"];
            $_SESSION['password'] = $data["password"];
            $_SESSION['telp'] = $data["telp"];
            $_SESSION['level'] = "petugas";
            $_SESSION['status'] = "login";
            header("location:petugas/index.php");
        }else{
            header("location:login.php?pesan=gagal");
        }
    }else{
        header("location:login.php?pesan=gagal");
    }
?>