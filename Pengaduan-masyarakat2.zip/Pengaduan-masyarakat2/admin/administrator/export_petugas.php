<?php
  include('../../koneksi.php');
  session_start();
// cek apakah yang mengakses halaman ini sudah login
if($_SESSION['level']==""){
	header("location:../index.php?pesan=belum_login");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Export data petugas</title>
    <style>
        table{
            width:100%;
            text-align:center;
        }
    </style>
</head>
<body>
    <?php
        $sekarang = date('d_M_Y');
        header("Content-type: application/vnd-ms-excel");
        header("Content-Disposition: attachment; filename=Data_Petugas_tanggal_".$sekarang.".xls");
	?>
    <table border="1">
        <tr>
            <td colspan="8">
                <h2>Export data petugas pengaduan masyarakat</h2>
            </td>
        </tr>
        <tr>
            <th>NO</th>
            <th>ID Petugas</th>
            <th>Nama Petugas</th>
            <th>Username</th>
            <th>Password</th>
            <th>Telp</th>
            <th>Created At</th>
            <th>Created By</th>
        </tr>
        <?php 
		$no = 1;
		$data = mysqli_query($koneksi,"SELECT * FROM petugas WHERE level='petugas'");
		while($data_export = mysqli_fetch_array($data)){
			?>
			<tr>
				<td><?php echo $no++; ?></td>
				<td><?php echo $data_export['id_petugas']; ?></td>
				<td><?php echo $data_export['nama_petugas']; ?></td>
				<td><?php echo $data_export['username']; ?></td>
				<td><?php echo $data_export['password']; ?></td>
				<td><?php echo $data_export['telp']; ?></td>
				<td><?php echo $data_export['created_at']; ?></td>
				<td><?php echo $data_export['created_by']; ?></td>
			</tr>
			<?php 
		}
		?>
    </table>
</body>
</html>