<?php 
    include '../../koneksi.php';
    $id_petugas = $_GET['id'];
    mysqli_query($koneksi,"DELETE FROM petugas where id_petugas='$id_petugas'");
    echo "<script>
            alert('Petugas dengan id ".$id_petugas." berhasil di hapus');
            window.location='petugas.php';
          </script>";
?>