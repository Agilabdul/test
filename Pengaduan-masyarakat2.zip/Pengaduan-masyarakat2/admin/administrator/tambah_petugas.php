<?php 
    include('../../koneksi.php');
    session_start();
    if($_SESSION['status']!="login"){
        header("location:../../login.php?pesan=belum_login");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../aset/bootstrap/css/bootstrap.min.css">
    <title>Halaman Administrator</title>
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
            <div class="container">
                <a class="navbar-brand" href="#">Administrator</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item p-2">
                            <a class="nav-link active" href="petugas.php">Petugas</a>
                        </li>
                        <li class="nav-item p-2">
                            <a class="nav-link" href="#">Masyarakat</a>
                        </li>
                        <li class="nav-item p-2">
                            <a class="nav-link" href="#">Pengaduan</a>
                        </li>
                        <li class="nav-item dropdown p-2">
                          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Hallo, <?= $_SESSION['username']; ?>
                          </a>
                          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="saya.php">Akun Saya</a>
                            <a class="dropdown-item" href="../../logout.php" onclick="return confirm('Anda yakin akan logout?')">Logout</a>
                          </div>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    
    <main role="main" style="margin-top: 100px;">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-body">
                            <h4>Tambah Data Petugas : </h4>
                            <form class="needs-validation mt-4" method="POST" action="" novalidate>
                                <div class="mb-3">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">Nama</span>
                                        </div>
                                        <input type="text" name="nama_petugas" class="form-control" id="nama_petugas">
                                        <div class="invalid-feedback" style="width: 100%;">
                                            Nama tidak boleh kosong!
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">Username</span>
                                            </div>
                                            <input type="text" name="username" class="form-control" id="username">
                                            <div class="invalid-feedback">
                                                Username tidak boleh kosong!
                                            </div>
                                        </div>	
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">Password</span>
                                            </div>
                                            <input type="password" name="password" class="form-control" id="password">
                                        </div>
                                        <div class="invalid-feedback">
                                            Password tidak boleh kosong!
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">No Telepon</span>
                                        </div>
                                        <input type="number" name="telp" class="form-control" id="telp">
                                        <div class="invalid-feedback" style="width: 100%;">
                                            No Telepon tidak boleh kosong!
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">Level</span>
                                        </div>
                                        <select name="level" class="form-control" required>
                                            <option selected>Pilih Level</option>
                                            <option value="Petugas">Petugas</option>
                                            <option value="Administrator">Administrator</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <!-- <div class="custom-file mb-3">
                                        <input type="file" class="custom-file-input" id="profil" name="profil">
                                        <label class="custom-file-label" for="profil">Foto Profil</label>
                                    </div> -->
                                    <input type="submit" name="save" class="btn btn-primary btn-sm" value="Save">
                                    <a href="petugas.php" class="btn btn-danger btn-sm">Kembali</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    
    <?php
        if (isset($_POST['save'])) {
            $nama_petugas   = $_POST['nama_petugas'];
            $username       = $_POST['username'];
            $password       = md5($_POST['password']);
            $telp           = $_POST['telp'];
            $level          = $_POST['level'];
            $created_at     = date('d M Y, H:i:s A');
            $created_by     = $_SESSION['nama_petugas'];
            $sql_cek        = mysqli_query($koneksi,"SELECT * FROM petugas WHERE telp='$telp'");
            $cek_telp       = mysqli_num_rows($sql_cek);
            if ($cek_telp>0) {
                echo "<script>
                        alert('No telepon yang anda masukan sudah di pakai!');
                        window.location='tambah_petugas.php';
                      </script>";  
            }else{
            $insert = mysqli_query($koneksi,"INSERT INTO petugas(nama_petugas,username,password,telp,level,created_at,created_by) 
            VALUES('$nama_petugas','$username','$password','$telp','$level','$created_at','$created_by')");
                echo "<script>
                        alert('Data petugas berhasil di tambah kan!');
                        window.location='petugas.php';
                      </script>";  
            }                  
        }
    ?>
    <script src="../../aset/bootstrap/js/jquery-3.5.1.slim.min.js"></script>
    <script src="../../aset/bootstrap/js/popper.min.js"></script>
    <script src="../../aset/bootstrap/js/bootstrap.min.js"></script>
    <script>
        $(".custom-file-input").on("change", function() {
            var fileName = $(this).val().split("\\").pop();
            $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
        });
    </script>
</body>
</html>