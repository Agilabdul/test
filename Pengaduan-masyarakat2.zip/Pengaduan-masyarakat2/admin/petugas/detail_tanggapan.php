<?php 
    include('../../koneksi.php');
    session_start();
    if($_SESSION['status']!="login"){
        header("location:../login.php?pesan=belum_login");
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../aset/bootstrap/css/bootstrap.min.css">
    <title>Pengaduan Anda</title>
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
            <div class="container">
                <a class="navbar-brand" href="index.php">Petugas</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item p-2">
                            <a class="nav-link active" href="index.php">Pengaduan</a>
                        </li>
                        <li class="nav-item dropdown p-2">
                          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Hallo, <?= $_SESSION['username']; ?>
                          </a>
                          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="saya.php?id_petugas=<?=$_SESSION['id_petugas'];?>">Akun Saya</a>
                            <a class="dropdown-item" href="../logout.php" onclick="return confirm('Anda yakin akan logout?')">Logout</a>
                          </div>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    
    <main role="main" style="margin-top: 100px;">
        <div class="container mt-3">
            <div class="row">
                <?php 
                    $id_pengaduan = $_GET['id_pengaduan'];
                    $data = mysqli_query($koneksi,"SELECT * FROM pengaduan WHERE id_pengaduan='$id_pengaduan'");
                    while($data_pengaduan = mysqli_fetch_array($data)){?>

                            <div class="col-8 mt-3">
                                <div class="card">
                                    <div class="card-header"><h4>Detail pengaduan anda</h4></div>
                                    <div class="card-body">
                                        <div class="media">
                                            <img src="../../aset/img/avatar1.png" class="mr-3" alt="profile" width="50px">
                                            <div class="media-body">
                                                <b>Anda</b> <br>
                                                <small><em><?= $data_pengaduan['tgl_pengaduan'];?></em></small> <br>
                                                <p class="text-justify"><?= $data_pengaduan['isi_laporan'];?>?</p>

                                                    <?php
                                                        $id_pengaduan = $_GET['id_pengaduan'];
                                                        $data = mysqli_query($koneksi,"SELECT * FROM tanggapan WHERE id_pengaduan='$id_pengaduan'");
                                                        while($data_tanggapan = mysqli_fetch_array($data)){?>
                                                        
                                                        <hr>
                                                        <div class="media mt-3">
                                                            <a class="mr-3" href="#">
                                                                <img src="../../aset/img/profile.png" class="mr-3" alt="profile" width="50px">
                                                            </a>
                                                            <div class="media-body">
                                                                <?php
                                                                $id_petugas = $data_tanggapan['id_petugas'];;
                                                                $data = mysqli_query($koneksi,"SELECT * FROM petugas WHERE id_petugas='$id_petugas'");
                                                                while($data_petugas = mysqli_fetch_array($data)){?>

                                                                <b><?= $data_petugas['nama_petugas'];?></b> <br>
                                                                
                                                                <?php
                                                                }?>
                                                                <small><em><?= $data_tanggapan['tgl_tanggapan'];?></em></small> <br>
                                                                <p class="text-justify"><?= $data_tanggapan['tanggapan'];?></p>
                                                            </div>
                                                        </div>
                                                        <?php
                                                        }
                                                    ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php
                    }?>

                <?php
                    $sql_cek    = mysqli_query($koneksi,"SELECT * FROM tanggapan WHERE id_pengaduan='$id_pengaduan'");
                    $cek_tanggapan  = mysqli_num_rows($sql_cek);
                    if ($cek_tanggapan<=0) {?>
                    <div class="col-4 mt-3">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="text-center">FORM TANGGAPAN</h4>
                                <form method="post" action="">
                                    <div class="form-group">
                                        <input type="hidden" name="status" class="form-control form-control-sm" id="status" value="selesai">
                                        <input type="hidden" name="id_petugas" class="form-control form-control-sm" id="id_petugas" value="<?= $_SESSION['id_petugas']; ?>">
                                        <input type="hidden" name="id_pengaduan" class="form-control form-control-sm" id="id_pengaduan" value="<?= $_GET['id_pengaduan']; ?>">
                                    </div>
                                    <div class="form-group">
                                        <textarea class="form-control" name="tanggapan" id="tanggapan" placeholder="Tanggapan" rows="5" autocomplete="off" required></textarea>
                                    </div>
                                    <input type="submit" name="tanggapi" value="Tanggapi" class="btn btn-success btn-sm" style="float:right;">
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php
                }?>
            </div>
        </div>
    </main>


	<?php 
        if (isset($_POST['tanggapi'])) {  
            $status = $_POST['status'];
            $id_pengaduan = $_POST['id_pengaduan'];
            $tgl_tanggapan = date("d M Y, H:i:s A");
            $tanggapan = $_POST['tanggapan'];
            $id_petugas = $_POST['id_petugas'];
            $sql_cek    = mysqli_query($koneksi,"SELECT * FROM tanggapan WHERE id_pengaduan='$id_pengaduan'");
            $cek_tanggapan  = mysqli_num_rows($sql_cek);
            if ($cek_tanggapan>0) {
              echo "<script>
                        alert('Anda sudah pernah menanggapi pengaduan ini!');
                        window.location='index.php';
                    </script>";
            }else{
                $insert = mysqli_query($koneksi,"INSERT INTO tanggapan VALUES('','$id_pengaduan','$tgl_tanggapan','$tanggapan','$id_petugas')");
                $insert .= mysqli_query($koneksi,"UPDATE pengaduan SET status='$status' WHERE id_pengaduan='$id_pengaduan'"); 
                echo "<script>
                        alert('$_GET[id_pengaduan] berhasil di tanggapi');
                        window.location='index.php';
                      </script>";       
            }
        }
	?>


    <script src="../../aset/bootstrap/js/jquery-3.5.1.slim.min.js"></script>
    <script src="../../aset/bootstrap/js/popper.min.js"></script>
    <script src="../../aset/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>