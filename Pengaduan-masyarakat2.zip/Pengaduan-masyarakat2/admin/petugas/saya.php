<?php 
    include('../../koneksi.php');
    session_start();
    if($_SESSION['status']!="login"){
        header("location:../login.php?pesan=belum_login");
    }
    if (isset($_GET['id_petugas'])) {
      $id_petugas = ($_GET["id_petugas"]);
      $query = "SELECT * FROM petugas WHERE id_petugas='$id_petugas'";
      $result = mysqli_query($koneksi, $query);
      if(!$result){
        die ("Query Error: ".mysqli_errno($koneksi).
          " - ".mysqli_error($koneksi));
      }
      $data = mysqli_fetch_assoc($result);
        if (!count($data)) {
            echo "<script>alert('Data tidak ada');window.location='../login.php';</script>";
        }
    } else {
      echo "<script>alert('Upss, NIK tidak di temukan?');window.location='../login.php';</script>";
    }    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../aset/bootstrap/css/bootstrap.min.css">
    <title>Akun Saya</title>
</head>
<body>    
    <header>
        <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
            <div class="container">
                <a class="navbar-brand" href="index.php">Petugas</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item p-2">
                            <a class="nav-link" href="index.php">Pengaduan</a>
                        </li>
                        <li class="nav-item active dropdown p-2">
                          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Hallo, <?= $_SESSION['username']; ?>
                          </a>
                          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="saya.php?id_petugas=<?=$_SESSION['id_petugas'];?>">Akun Saya</a>
                            <a class="dropdown-item" href="../logout.php" onclick="return confirm('Anda yakin akan logout?')">Logout</a>
                          </div>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <main role="main" style="margin-top: 100px;">
        <div class="container">
            <div class="row justify-content-md-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-body">
                            <?php
                                if (isset($_POST['update'])) {  
                                    $id_petugas     = $_POST['id_petugas'];
                                    $nama_petugas   = $_POST['nama_petugas'];
                                    $username       = $_POST['username'];
                                    $password       = md5($_POST['password']);
                                    $telp           = $_POST['telp'];
                                    mysqli_query($koneksi, "UPDATE petugas SET nama_petugas='$nama_petugas', username='$username', password='$password', telp='$telp' WHERE id_petugas='$id_petugas'");                                  
                                    header("location:../login.php?pesan=update");
                                }
                            ?>
                            <h3 class="text-center">AKUN SAYA</h3>
                            <form class="needs-validation mt-4" method="POST" action="" novalidate>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">ID</span>
                                            </div>
                                            <input type="number" name="id_petugas" class="form-control" id="id_petugas" value="<?= $_SESSION['id_petugas']; ?>" readonly>
                                            <div class="invalid-feedback">
                                                ID Petugas tidak boleh kosong!
                                            </div>
                                        </div>	
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">Nama</span>
                                            </div>
                                            <input type="text" name="nama_petugas" class="form-control" id="nama_petugas" value="<?= $_SESSION['nama_petugas']; ?>">
                                        </div>
                                        <div class="invalid-feedback">
                                            Nama tidak boleh kosong!
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">Username</span>
                                            </div>
                                            <input type="text" name="username" class="form-control" id="username" value="<?= $_SESSION['username']; ?>">
                                            <div class="invalid-feedback">
                                                Username tidak boleh kosong!
                                            </div>
                                        </div>	
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">Password</span>
                                            </div>
                                            <input type="password" name="password" class="form-control" id="password" value="<?= $_SESSION['password']; ?>">
                                        </div>
                                        <div class="invalid-feedback">
                                            Password tidak boleh kosong!
                                        </div>
                                    </div>
                                </div>
            
                                <div class="mb-3">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">No. Telepon</span>
                                        </div>
                                        <input type="number" name="telp" class="form-control" id="telp" value="<?= $_SESSION['telp']; ?>">
                                        <div class="invalid-feedback" style="width: 100%;">
                                            Telepon tidak boleh kosong!
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <!-- <div class="custom-file mb-3">
                                        <input type="file" class="custom-file-input" id="profil" name="profil">
                                        <label class="custom-file-label" for="profil">Foto Profil</label>
                                    </div> -->
                                    <input type="submit" name="update" class="btn btn-primary btn-sm" value="update">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <script src="../../aset/bootstrap/js/jquery-3.5.1.slim.min.js"></script>
    <script src="../../aset/bootstrap/js/popper.min.js"></script>
    <script src="../../aset/bootstrap/js/bootstrap.min.js"></script>
    <script>
        $(".custom-file-input").on("change", function() {
            var fileName = $(this).val().split("\\").pop();
            $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
        });
    </script>
</body>
</html>